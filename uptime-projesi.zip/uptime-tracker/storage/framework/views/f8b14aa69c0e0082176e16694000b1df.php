<tr>
<td>
<table class="footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td class="content-cell" align="center">
<?php echo new \Illuminate\Support\EncodedHtmlString(Illuminate\Mail\Markdown::parse($slot)); ?>

</td>
</tr>
</table>
</td>
</tr>
<?php /**PATH /home/iso/Documents/GitHub/laravel-uptime-api/uptime-tracker/vendor/laravel/framework/src/Illuminate/Mail/resources/views/html/footer.blade.php ENDPATH**/ ?>