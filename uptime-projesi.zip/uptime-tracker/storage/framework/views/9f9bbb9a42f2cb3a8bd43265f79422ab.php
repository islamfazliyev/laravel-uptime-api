<table class="subcopy" width="100%" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td>
<?php echo new \Illuminate\Support\EncodedHtmlString(Illuminate\Mail\Markdown::parse($slot)); ?>

</td>
</tr>
</table>
<?php /**PATH /home/iso/Documents/GitHub/laravel-uptime-api/uptime-tracker/vendor/laravel/framework/src/Illuminate/Mail/resources/views/html/subcopy.blade.php ENDPATH**/ ?>