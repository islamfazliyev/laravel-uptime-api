<?php echo e($slot); ?>

<?php /**PATH /home/iso/Documents/GitHub/laravel-uptime-api/uptime-tracker/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>