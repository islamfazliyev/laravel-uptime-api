<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/iso/Documents/GitHub/laravel-uptime-api/uptime-tracker/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>